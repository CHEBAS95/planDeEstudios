import { sum, restas, suma, mult } from './sum.mjs';

let num1 = sum(1, 2, 4);
let num2 = restas(5, 3);
let num3 = suma(9, 5);
let num4 = mult(5, 6);

// Suma de `num1`, `num3` y `num4`
let num5 = sum(num1, num3, num4);

console.log("Resultado de sum(1, 2, 4):", num1);
console.log("Resultado de restas(5, 3):", num2);
console.log("Resultado de suma(9, 5):", num3);
console.log("Resultado de mult(5, 6):", num4);
console.log("Resultado final sum(num1, num3, num4):", num5);
