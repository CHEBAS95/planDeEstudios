export function sum(a, b, c) {
  return a + b + c;
}

export function suma(a, b) {
  return a + b;
}

export function restas(a, b) {
  return a - b;
}

export function mult(a, b) {
  return a * b;
}
