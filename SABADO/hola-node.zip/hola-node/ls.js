const fs = require('node:fs');

const allFiles = fs.readdir('.', (err, data)=>{
    if(err){
        console.log('error al leer el directorio',err);
        return;
    }
    data.forEach(data =>{
        console.log(data)
    })
})