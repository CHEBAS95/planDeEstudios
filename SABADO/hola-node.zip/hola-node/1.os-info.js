const { log } = require('node:console')
const { console } = require('node:inspector')
const os = require('node:os')
//si es archivo .mjs se cambia required por import

console.log('Información del sistema operativo:')
console.log('-------------------')

console.log('Nombre del sistema operativo', os.platform())
console.log('Versión del sistema operativo', os.release())
console.log('Arquitectura', os.arch())
console.log('CPUs', os.cpus())//escalar procesos en nodes

console.log('',os.networkInterfaces);

console.log('Memoria libre', os.freemem() / 1024 / 1024)
console.log('Memoria total', os.totalmem() / 1024 / 1024)
console.log('uptime', os.uptime() / 60 / 60)
console.log('uptime', os.uptime()/60/60)
//inifo del sistema opretaivo
console.log('------------------------------------------')