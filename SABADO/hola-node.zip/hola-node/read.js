const fs = require('node:fs')

console.log('empiezqa a leer el primer archivo...');
fs.readFile("text/archivo.txt", "utf8", (err, data) => {
  if (err) {
    console.error(err);;
    return;
  }
  console.log("conteniodo del primer archivo :", data); // Esto mostrará el contenido del archivo leído en la consola
});

console.log("mientras veo un vidio");

console.log("lee sgundo archivo ...");

fs.readFile("text/archivo2.txt", "utf-8", (err, data) => {
  if (err) {
    console.log(err)
    return;
  }
  console.log("contenido del segundo archivo", data);
});
