const path = require("node:path");
const fs = require("node:fs");
const { error } = require("node:console");

console.log(path.sep);

const textPeht = path.join(__dirname, "text", "archivo.txt");
console.log(textPeht);

const readText = fs.readFile(textPeht, "utf-8", (err, data) => {
  if (err) {
    console.error("error aal leer el archivo", err.message);
    return;
  }
  console.log("contenido del archivop :", data);
});

console.log('--------------------');

const resolve = path.resolve('archivo.txt')

console.log(resolve);

