//de forma sincornica
const fs = require('node:fs')

const stats = fs.statSync('./archivo.txt')
const stats1 = fs.statSync('./expCommon')
const readText = fs.readFileSync('./archivo.txt','utf-8')

console.log(
    stats.isDirectory(),
    stats.isFile(),
    stats.size,
);
console.log(readText);




console.log('-------------------------------');

console.log(
    stats1.isDirectory(),
    stats1.isFile(),
    stats1.size,
    
);

