
const{ sum ,suma, restas, mult} = require ('./suma')

let sum1 = sum(1, 2, 3);
let restas1 = restas(5, 9);
let suma1 =  suma(5, 23);
let mult1 = mult(5, 5);

console.log(sum1);
console.log(restas1);
console.log(suma1);
console.log(mult1);

console.log('el resultado que se nesesita es '+sum1+' y ' + mult1 +'='+ (+sum1+mult1));

