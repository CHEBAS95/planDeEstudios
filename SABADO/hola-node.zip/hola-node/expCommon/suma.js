function sum(a, b, c) {
  return a + b + c;
}

function restas(a, b) {
  return a - b;
}

function suma(a, b) {
  return a + b;
}

function mult(a, b) {
  return a * b;
}

module.exports = { suma , sum, restas, mult};
